# Solid Workbench toolbar design

Accepted visual direction, 12 November 2026.

Open `index.html` directly in a browser. No installation, build step, server or
internet connection is required. Use **Wide / Mobile** to compare layouts, and
**Dock / Float** to change the formatting toolbar's placement.

## Included files

- `index.html`: standalone interactive preview with embedded icons and supporting scripts.
- `preview-source.html`: the original editable HTML/CSS/JavaScript fragment used for the preview.
- `THIRD-PARTY-NOTICES.txt`: licences for the embedded icon and positioning libraries.

## Design decisions

- Application title, actions and the angled account corner share one compact row.
- In wide view, the filename is the final breadcrumb segment. The path uses the
  available width, with file actions at the right.
- Mobile retains separate location and selected-file rows, collapsed ancestors,
  and a Back to files action.
- Dark neutral surfaces distinguish navigation/tools from document content.
- Spacing and alignment replace most borders and separators.
- Hover and selected states use neutral greys. The configurable highlight colour
  is reserved for actions requiring emphasis.
- Floating and docked formatting tools share their controls. Floating tools use
  a soft shadow, and Dock remains on the same row.

The source exposes `--wb-highlight` and `--wb-highlight-text` for the action
colour pair. The preview currently uses a fixed dark theme.

This is a design prototype, not a patch for the Solid Workbench repository.
Formatting, disclosures, docking and preview-width controls are interactive.
File operations and navigation are illustrative; no Solid connection or storage
operation is performed. Iframe containment and scrolling behaviour still need
implementation and browser verification in the actual apps.
