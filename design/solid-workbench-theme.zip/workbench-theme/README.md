# Muze Workbench theme for the-ds

A small, opt-in CSS extension for short application forms, toolbars and dialogs.
It implements the visual direction developed for Solid Workbench: square
controls, blue primary actions, two-tone surfaces, subtle dividers, angled
corner close buttons and spacious dropdown chevrons. Floating surfaces use
shadows in light mode and glows in dark mode.

The public namespace is **`mw-`** for classes and **`--mw-*`** for properties.
`data-mw-*` and `mw-*` IDs in the examples belong to the demonstration.
No build step or JavaScript library is required by the theme.

## Files and quick start

- `workbench-theme.css`: the reusable theme; load after the-ds.
- `examples.html`: interactive, offline examples, including modal forms,
  field states, a compact contextual toolbar and a dockable non-modal panel.
- `vendor/theds.css`: the-ds snapshot for the example only; its optional remote
  Google Fonts import was removed so opening the example makes no network requests.
- `vendor/LICENSE-theds.txt`: upstream MIT license.

Unzip the package and open `examples.html`. Use **Preferences** to switch between
system, light and dark appearance; use **Float / Dock** to compare panel states.
**New folder** and **Add link** open native modal dialogs. Submit an empty name
or malformed URL to inspect validation. All actions are local demonstrations:
there are no Pod writes, actual folders, network calls or persistent saves.

In an application, use your existing the-ds stylesheet:

```html
<link rel="stylesheet" href="theds.css">
<link rel="stylesheet" href="workbench-theme.css">

<main class="mw-theme" data-mw-theme="system">
  <!-- Your application -->
</main>
```

The scope provides tokens; only elements with theme classes receive component
styling. The theme does not override global `input`, `label`, `button` or `h2`
selectors, or change `--ds-*` values. The underlying the-ds stylesheet still has
its own global element defaults.

For most applications, put `mw-theme` on `body` so that native dialogs inherit
the tokens too. A dialog in the browser top layer still inherits from its DOM
ancestors. For shadow roots, include the styles inside that root and put
`mw-theme` on an internal wrapper.

## Cascade and component boundaries

The stylesheet retains the-ds layer order:

```css
@layer reset, setup, theme, base, component, page, utility;
```

| Layer | Extension responsibility |
| --- | --- |
| `theme` | One explicit the-ds adapter, palette and public properties |
| `base` | Typography and surface on the opt-in `mw-theme` scope |
| `component` | Atoms, field groups, toolbars, panels and dialogs |
| `page` | Reserved for app composition and overrides; demonstrated in HTML |
| `utility` | Screen-reader text and reliable native `hidden` behavior |

Control atoms use `component` so they consistently override the-ds's global
form element defaults. Atomic Design describes composition rather than requiring
one cascade layer per atom. The file is organized from small parts to assemblies.
Selectors are flat, classes are applied directly, and no CSS nesting is used.
The scoped `[hidden]` utility is the sole descendant selector. Its `!important`
is intentional: it keeps hidden content hidden despite a component's display rule.

All `--ds-*` reads are confined to the adapter on `.mw-theme`: font, spacing,
shadow and glow tokens. Components consume only `--mw-*`. The Workbench palette
is intentional rather than an alias of the host's default primary color.

The adapter resolves host values at each `.mw-theme` boundary. Set overrides on
that same element or introduce a new explicit theme boundary. An inherited alias
does not recalculate when an underlying `--ds-*` token changes on a descendant.
Likewise, override derived properties such as `--mw-gap` explicitly on a child
component if only its spacing should change.

```css
@layer page {
  .my-workspace {
    --mw-font: Arial, Helvetica, sans-serif;
    --mw-inset: 1.25rem;
    --mw-gap: 1rem;
    --mw-accent: light-dark(#225d96, #9ccaff);
    --mw-on-accent: light-dark(white, #142435);
  }
}
```

Apply `class="mw-theme my-workspace"` together. Replace the adapter to use a
different design system; the component rules themselves need no host variables.

## Component vocabulary

| Level | Classes | Purpose |
| --- | --- | --- |
| Atoms | `mw-button`, `mw-button-primary`, `mw-button-quiet` | Native actions and toggles |
| Atoms | `mw-label`, `mw-control`, `mw-textarea`, `mw-hint`, `mw-error`, `mw-status` | Labels, input surfaces and feedback |
| Atoms | `mw-icon`, `mw-close`, `mw-menu-button`, `mw-menu-chevron` | Icons, corner close and menu trigger |
| Molecules | `mw-field`, `mw-fields`, `mw-field-row` | Field and responsive form composition |
| Molecules | `mw-select-wrap`, `mw-select`, `mw-chevron` | Native single select with padded chevron |
| Molecules | `mw-choices`, `mw-legend`, `mw-choice`, `mw-choice-input` | Native checkboxes/radios and groups |
| Molecules | `mw-actions` | Wrapping action row |
| Organisms | `mw-mainbar`, `mw-main-name`, `mw-main-status`, `mw-main-button` | Compact application bar |
| Organisms | `mw-toolbar`, `mw-toolbar-field`, `mw-toolbar-floating` | Contextual controls, optionally floating |
| Organisms | `mw-panel`, `mw-panel-docked`, `mw-panel-floating` | Dockable non-modal dialog/panel |
| Organisms | `mw-panel-header`, `mw-panel-title`, `mw-panel-action`, `mw-panel-content`, `mw-panel-footer` | Shared panel/dialog parts |
| Organisms | `mw-dialog` | Native `<dialog>` surface; can also carry `ds-dialog` |

Use `mw-control` for ordinary text-like inputs, single selects and textareas.
Use `mw-choice-input` for radios/checkboxes. File inputs, ranges, color pickers
and multi-select widgets are not skinned by this first version; keep their native
behavior until a concrete application needs a separate component.

## Field markup

```html
<div class="mw-field">
  <label class="mw-label" for="folder-name">Folder name (required)</label>
  <input class="mw-control" id="folder-name" name="name" required
         aria-describedby="folder-hint folder-error">
  <p class="mw-hint" id="folder-hint">In Documents / Workbench</p>
  <p class="mw-error" id="folder-error" hidden></p>
</div>
```

When presenting an error, set `aria-invalid="true"`, reveal a specific message
and focus the first invalid field after failed submission. The example also
announces its errors using `role="alert"`; avoid redundant repeated announcements
when adapting this to an app. Hints and errors wrap naturally without fixed heights.
`readonly` stays selectable; `disabled` remains unavailable and visually distinct.
Keep required labels and persistent field labels visible; placeholders are examples.

```html
<label class="mw-field" for="sort-order">
  <span class="mw-label">Sort by</span>
  <span class="mw-select-wrap">
    <select class="mw-control mw-select" id="sort-order">
      <option>Last edited</option>
      <option>Name</option>
    </select>
    <span class="mw-chevron" aria-hidden="true"></span>
  </span>
</label>
```

The browser owns the select's picker and keyboard behavior. Only the closed
control's arrow is styled. It has `0.75rem` right/inline-end clearance (12px at
the default root size). Forced colors restore the native arrow.

## Three different UI patterns

### Main application bar

Only buttons, button names, document/application names and status indicators
belong here. **No text fields, selects or other form inputs.**
`--mw-main-height` is shared by the bar and its preferences/action buttons;
the default is `2.75rem` (44px). The row does not wrap. The app chooses which
text labels to hide or which secondary actions to move into an overflow menu.
Keep icon-only actions named for assistive technology. Do not merely clip actions.
Use `role="toolbar"` only if the application also implements its arrow-key model;
the example uses ordinary buttons and Tab navigation.

### Contextual toolbar

Use `mw-toolbar` for a small group of controls such as formatting. It may contain
form inputs and be taller than the main bar. `mw-toolbar-floating` adds elevation.
The app owns placement; **never dock a contextual toolbar against the main bar at
the top of the viewport**. A bottom or side dock is an application layout decision.

### Dockable dialog (non-modal panel)

Richer contextual forms get a title, shared angled close button, content area and
optional footer. They can float or dock at a content edge. The example docks at
the bottom, preserving a clear boundary from the top bar.

```html
<section class="mw-panel mw-panel-docked" aria-labelledby="search-title">
  <header class="mw-panel-header">
    <h2 class="mw-panel-title" id="search-title">Search &amp; sort</h2>
    <button class="mw-close" type="button" aria-label="Close search">
      <svg class="mw-icon" viewBox="0 0 24 24" aria-hidden="true">
        <path d="m6 6 12 12M6 18 18 6"/>
      </svg>
    </button>
  </header>
  <div class="mw-panel-content"><!-- Fields --></div>
</section>
```

Swap `mw-panel-docked` for `mw-panel-floating`; keep the same DOM, input values,
labels and close button. Both positions use the same two-tone composition and
subtle dividers. Floating adds a shadow or glow; docking removes elevation.
The decorative angled background is a pseudo-element, so it does not clip the
actual button's focus ring or shrink its rectangular hit area.

This is a **visual dockable-dialog pattern**, not a modal dialog. A labelled
`section` gives it region semantics. It does not trap focus or make content inert.
If an app instead uses `role="dialog"`, it must implement and test the appropriate
non-modal interaction and focus behavior. Avoid adding `aria-modal="true"` here.

The CSS does not implement drag, resize, docking geometry or pointer capture.
The example switches classes in normal document flow: it demonstrates appearance
and retained state, not a draggable window manager. Production floating panels
need positioning constrained to their app viewport, including the software keyboard.
Always provide button alternatives to any later drag-to-dock interaction.

## Modal dialogs and app behavior

Use `<dialog class="ds-dialog mw-dialog">` with `showModal()` and the shared
panel header/content/footer classes. Give it an accessible title, deliberate
initial focus and a named close button. `mw-dialog:not([open])` protects against
the-ds's surface display rule accidentally displaying a closed native dialog.

The whole dialog scrolls within a viewport limit, so footer and fields remain
reachable without a permanently pinned footer obscuring content. Phone layouts
use nearly the full width. Application-specific fullscreen layouts can be added
in `page`; keep keyboard-open viewport behavior under test.

CSS does not own validation, form submission, unsaved edits, asynchronous writes,
focus restoration or persistence. Keep those in the application. The example's
small inline script uses native DOM APIs for demonstration only. In Solid
Workbench, wire the same markup through the existing SimplyFlow commands,
bindings and named editable behaviors rather than introducing a second renderer.

Closing via X, Cancel or Escape follows one handler in the examples. Dismissal
preserves the current draft while this page remains open. Production apps must
choose and explain draft retention/discard semantics and save-in-progress behavior.
Saved locally and synced remotely are different states; the theme only styles
their status messages.

## Appearance and public tokens

`data-mw-theme="system"` (or omission) follows the OS. `light` and `dark` override
it. Existing `ds-lightmode` or `ds-darkmode` on the **same `mw-theme` element**
are also supported; use one appearance mechanism per boundary. A class on an
unrelated ancestor is not an automatic adapter boundary.

| Property | Default / purpose |
| --- | --- |
| `--mw-font`, `--mw-space` | Adapted the-ds font and spacing |
| `--mw-surface`, `--mw-chrome` | Content surface and quiet UI surface |
| `--mw-text`, `--mw-muted`, `--mw-error` | Main, secondary and error text |
| `--mw-border`, `--mw-divider` | Control boundaries and quieter structural lines |
| `--mw-accent`, `--mw-on-accent`, `--mw-selected` | Primary action and selected state |
| `--mw-close-surface`, `--mw-focus` | Angled close background and focus ring |
| `--mw-radius` | `0` for square controls |
| `--mw-target` | `2.75rem`, minimum control/button height |
| `--mw-main-height` | Main bar and its buttons; defaults to `--mw-target` |
| `--mw-gap`, `--mw-inset` | Form gaps and panel padding |
| `--mw-chevron-inset` | `0.75rem` inline-end clearance |
| `--mw-shadow`, `--mw-glow` | Adapted the-ds elevation effects |
| `--mw-elevation` | Appearance-selected effect; glows replace shadows in dark mode |

Override elevation on the theme boundary when matching a different host palette.
The palette uses `light-dark()`; elevation switches explicitly because shadows
are not colors. No animation is included.

## Scope and verification

Built against the-ds source commit
`2583aa38913d8352384f7a041ebf5262581ef735` (package version 0.2.8).
Upstream: <https://github.com/muze-nl/the-ds>.
The bundled vendor stylesheet is its distribution file with only the remote font
import removed. Use your app's own the-ds build in production rather than loading
two copies. The example selects Arial through `--mw-font` to match the reviewed
mockups; the reusable theme otherwise adapts the host body font.

This version targets browsers supporting cascade layers, `light-dark()`, logical
properties, container queries and native `<dialog>`. No polyfills are bundled.

Completed checks: CSS syntax parsing (300 declarations), the host-token adapter
boundary, HTML IDs and label/description references, local stylesheet paths,
button names and the no-inputs main-bar rule. DOM simulation verified filtering,
sorting, retained values through docking/closing/reopening, error display and
recovery, appearance selection, formatting toggles and example submissions.
Native dialog methods were stubbed in that simulation: it does not verify browser
modality, focus trapping, native select behavior or visual layout.

These checks are not a claim of WCAG conformance. Before integrating, manually
check Chromium, Firefox and Safari:

- Keyboard access, close/reopen focus, radio/select keys and validation messages.
- Screen-reader names, grouping and announcements, including error recovery.
- Light, dark and forced colors; focus on angled close buttons and selected tools.
- 320px layouts, 200% text, 400% zoom, long labels and phone keyboards.
- Bottom/side docking and floating placement, without obstructing focused controls.

Browser rendering could not run in the creation environment: Chromium's process
startup was blocked by unavailable socket operations. Browser screenshots, mobile
keyboard behavior and assistive-technology behavior remain unverified.
