# Solid Workbench icons

Twelve hand-authored SVG icons based on the approved cobalt/coral concept,
including the revised Forms checklist. Flat, transparent geometry; no embedded
raster images, fonts, scripts or dependencies. These are vector redrawings of
the concept rather than automatic pixel traces. The source paths remain editable.

## Files

- `solid-workbench.svg`: SVG symbol sprite; every symbol has a 32 × 32 viewBox.
- `icons/*.svg`: standalone SVGs, suitable for images and SVG favicons.
- `favicons/*.png` and `*.ico`: raster favicons at 16, 24, 32 and 48 pixels.
- `preview.html`: self-contained preview with actual 16/24/32 CSS pixel samples.
- `preview.svg`: visual sheet using the same symbol definitions.
- `preview.png`: rendered visual sheet.

## Sprite usage

Serve the sprite from the same origin as your application:

```html
<svg width="24" height="24" role="img" aria-label="Contacts">
  <use href="/assets/solid-workbench.svg#sw-contacts"></use>
</svg>
```

For decorative icons beside a visible label use `aria-hidden="true"` on the
outer SVG instead. For an inline sprite, insert its symbol definitions into a
zero-sized SVG once, then use `href="#sw-contacts"`. See `preview.html`.
External sprite references require HTTP(S); the included preview works from disk
because it inlines the sprite. The symbol sprite alone is intentionally blank
when opened as an image: open `preview.svg` to see the sheet.

## Symbol IDs

`sw-workbench`, `sw-contacts`, `sw-files`, `sw-profile`, `sw-zett`,
`sw-notebook`, `sw-projects`, `sw-crm`, `sw-documents`, `sw-knowledge`,
`sw-forms`, `sw-chat`.

## Favicon usage

Use standalone files, not a symbol reference, for browser favicons:

```html
<link rel="icon" href="/assets/icons/contacts.svg" type="image/svg+xml">
<link rel="alternate icon" href="/assets/favicons/contacts.ico">
```

The favicons are rendered from the same geometry, with transparent backgrounds.
Small-size samples were inspected on light and dark backgrounds; browser and
operating-system rendering can vary. No separate micro-icon redesign is included.

## Colours

Cobalt `#2455FF`; coral `#FF503F`. Negative spaces are transparent.
Fill colours have explicit fallbacks and support `--sw-blue` / `--sw-coral`
when used inline. Forms ticks use cobalt strokes. Styles on a parent HTML page
do not cascade into SVGs loaded using `<img>` or favicon links.
