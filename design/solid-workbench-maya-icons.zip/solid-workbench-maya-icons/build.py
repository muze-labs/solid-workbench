#!/usr/bin/env python3
"""Rebuild the hand-authored SVG family and its PNG/ICO exports.

Requires Python 3, Pillow, and Inkscape on PATH. No network access needed.
"""
from pathlib import Path
import html
import io
import subprocess
from PIL import Image

ROOT = Path(__file__).resolve().parent
BLUE = '#259CCA'  # Rounded sRGB conversion of oklch(65% 0.12 230)
CORAL = '#CE7162' # Rounded sRGB conversion of oklch(65% 0.12 30)
INK = '#102E42'
NS = 'http://www.w3.org/2000/svg'

def path(d, fill=BLUE, **attrs):
    extra = ''.join(f' {k.replace("_", "-")}="{v}"' for k,v in attrs.items())
    return f'<path d="{d}" fill="{fill}"{extra}/>'

def rect(x,y,w,h,r=0,fill=BLUE):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}"/>'

def circle(x,y,r,fill=BLUE):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}"/>'

def line(d,color=BLUE,width=4):
    return f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linecap="round" stroke-linejoin="round"/>'

def cut(name, body, holes):
    # Luminance masks cut genuine transparency, including on dark backgrounds.
    return (f'<defs><mask id="sw-{name}-cut" maskUnits="userSpaceOnUse" '
            'x="0" y="0" width="64" height="64" style="mask-type:luminance">'
            + rect(0,0,64,64,fill='white') + holes + '</mask></defs>'
            + f'<g mask="url(#sw-{name}-cut)">{body}</g>')

ICONS = {}
# Workbench: four independently rounded stepped modules with open center.
module = 'M11 5H26Q28 5 28 7V13Q28 15 26 15H24V18Q24 20 22 20H19V24Q19 26 17 26H7Q5 26 5 24V11Q5 5 11 5Z'
parts = []
for i,col in enumerate((BLUE,CORAL,BLUE,CORAL)):
    parts.append(f'<g transform="rotate({i*90} 32 32)">'+cut(f'workbench-{i}',path(module,col),circle(15,14,3,'black'))+'</g>')
ICONS['workbench']=''.join(parts)

# A shared compact face. White in the reference becomes transparent here.
face = ('M36 19H47Q50 19 51 22L55 30Q56 32 53 32H50V40'
        'Q50 42 48 42H40V48H32V55H23V48H16Q11 48 11 43V32Q11 26 17 26H29Q29 19 36 19Z')
eye = rect(37,23,10,3.6,1.8)
ear_cut = line('M18 44V33H27V40H23','black',3.6)
contact_body = rect(7,7,43,50,9)
tabs = cut('contacts-tabs',rect(48,10,13,15,4,CORAL)+rect(48,33,13,15,4,CORAL),circle(54,17.5,2.5,'black')+circle(54,40.5,2.5,'black'))
ICONS['contacts'] = tabs+cut('contacts',contact_body,path(face,'black'))+eye
# Ear block sits within the negative face and carries a transparent angular return.
ICONS['contacts'] += cut('contacts-ear',rect(14,29,17,16,2),ear_cut)

profile_body = path('M20 11H48Q54 11 55 17L60 28Q61 32 57 32H55V41Q55 45 51 45H44V55H16Q6 55 6 45V25Q6 11 20 11Z')
ICONS['profile'] = cut('profile',profile_body,path(face,'black'))+eye
ICONS['profile'] += cut('profile-ear',rect(14,29,17,16,2,CORAL),ear_cut)

# Files: stepped upper opening and lower return integrated in the folder lip.
file_body = path('M6 10Q6 6 12 6H24Q27 6 29 10L32 16H51Q59 16 59 24V53Q59 58 53 58H11Q5 58 5 52V11Z')
file_open = line('M3 25H24L29 31H63','black',5)
file_return = line('M24 61V49H39V39H61','black',5)
file_coral = path('M42 42H59V52Q59 58 53 58H28V52H42Z',CORAL)
file_coral = cut('files-coral',file_coral,line('M46 60V49H52V52','black',3.8))
ICONS['files'] = cut('files',file_body,file_open+file_return+path('M39 42H64V64H28V52H39Z','black'))+file_coral

# Zett: three note glyphs and a single shared branching connector.
def note(name,x,y,w,h,color):
    return cut(name,rect(x,y,w,h,5,color),line(f'M{x+6} {y+h+1}V{y+6}H{x+w-5}V{y+12}H{x+11}','black',3.4))
ICONS['zett']=line('M32 22V32M12 44V34H52V44',BLUE,4.5)
ICONS['zett']+=note('zett-top',20,5,25,20,BLUE)+note('zett-left',3,41,25,19,CORAL)+note('zett-right',36,41,25,19,BLUE)

notebook_body=rect(7,5,50,54,8)
notebook_holes=(line('M20 2V61','black',3.5)+line('M4 24H20M4 39H20','black',3.5)
                +line('M20 53H49V41H38V47H43','black',3.6)
                +path('M29 2H46V32L37.5 25L29 32Z','black'))
ICONS['notebook']=cut('notebook',notebook_body,notebook_holes)+path('M31 5H44V27L37.5 22L31 27Z',CORAL)

project_body=(path('M6 38Q6 35 9 35H13V29Q13 27 15 27H21V58H10Q6 58 6 54Z')
              +path('M25 24Q25 21 28 21H32V15Q32 13 34 13H40V58H25Z',CORAL)
              +path('M44 10H49V5Q49 3 51 3H56Q60 3 60 7V54Q60 58 56 58H44Z'))
ICONS['projects']=cut('projects',project_body,''.join(circle(x,49,3,'black') for x in (14,32.5,52)))

# Reuse precisely the same compact head on both sides of CRM.
def crm_head(name,color):
    return (cut(name,profile_body.replace(BLUE,color),path(face,'black'))
            +eye.replace(BLUE,color)+cut(name+'-ear',rect(14,29,17,16,2,color),ear_cut))
ICONS['crm']=('<g transform="translate(0 13) scale(.51 .67)">'+crm_head('crm-left',BLUE)+'</g>'
              '<g transform="translate(64 13) scale(-.51 .67)">'+crm_head('crm-right',CORAL)+'</g>')

document_body=path('M13 5H35V24H56V52Q56 59 49 59H20V54H13V47H7V13Q7 5 13 5Z')
ICONS['documents']=cut('documents',document_body,rect(17,37,29,4,2,'black')+rect(17,46,29,4,2,'black'))+path('M39 5L56 21H39Z',CORAL)

# Knowledge: mirrored page shapes; angular return grows from page edge.
page='M5 16Q18 8 30 16V49Q18 42 5 49Z'
page_hole=line('M9 49H24V32H14V40H19','black',3.4)
left=cut('knowledge-left',path(page),page_hole)
right='<g transform="translate(64 0) scale(-1 1)">'+cut('knowledge-right',path(page),page_hole)+'</g>'
base=path('M5 53Q19 47 32 57Q45 47 59 53V60Q46 54 32 63Q18 54 5 60Z',CORAL)
ICONS['knowledge']=left+right+base

forms_body=path('M13 12H22V8Q22 6 25 6H39Q42 6 42 8V12H51Q59 12 59 20V49Q59 57 51 57H43V51H38V57H26V51H21V57H13Q5 57 5 49V20Q5 12 13 12Z')
forms_holes=(line('M20 16H26V12H38V16H44','black',3)
             +line('M14 39L18 43L26 34','black',4.6)
             +rect(33,25,16,4.2,2.1,'black')+rect(33,37,16,4.2,2.1,'black'))
ICONS['forms']=cut('forms',forms_body,forms_holes)+line('M14 27L18 31L26 22',CORAL,4.6)

back=path('M31 8H53Q60 8 60 15V38Q60 45 53 45H52V55L41 45H30Q24 45 24 38V15Q24 8 31 8Z',CORAL)
back=cut('chat-back',back,line('M31 41H52V20H42V28H47','black',3.8))
front=path('M11 24H34Q41 24 41 31V48Q41 54 34 54H18L5 63V31Q5 24 11 24Z')
# Transparent separation between overlapping speech blocks.
back=cut('chat-gap',back,path('M11 21H34Q44 21 44 31V48Q44 57 34 57H18L2 64V31Q2 21 11 21Z','black'))
front=cut('chat-front',front,line('M44 49H14V33H30V40H23','black',3.8))
ICONS['chat']=back+front

screen=rect(5,10,54,38,5)+rect(28,46,8,9)+rect(22,54,20,4.5,2.25)
ICONS['present']=cut('present',screen,rect(10,15,44,28,3,'black'))
ICONS['present']+=rect(14,19,16,6,1.5,CORAL)+rect(14,33,28,5,2)
ICONS['present']+=path('M34 19H47Q50 19 50 23V38H45V25Q45 24 44 24H34Z')

graph_axes=line('M7 12V56H59',BLUE,5)
graph_bars=rect(13,44,12,9,3)+rect(29,36,12,17,3)+rect(45,29,12,24,3)
graph_points=((18,35),(34,25),(51,17))
graph_line='M18 35L34 25L51 17'
separation=line(graph_line,'black',8)+''.join(circle(x,y,6,'black') for x,y in graph_points)
ICONS['graph']=graph_axes+cut('graph-bars',graph_bars,separation)
ICONS['graph']+=cut('graph-line',line(graph_line,CORAL,4.2)+''.join(circle(x,y,4.8,CORAL) for x,y in graph_points),''.join(circle(x,y,1.8,'black') for x,y in graph_points))

ORDER=['workbench','contacts','files','profile','zett','notebook','projects','crm','documents','knowledge','forms','chat','present','graph']
LABELS={n:('CRM' if n=='crm' else n.title()) for n in ORDER}

def svg(body, title=None):
    t=f'<title>{html.escape(title)}</title>' if title else ''
    return f'<svg xmlns="{NS}" width="64" height="64" viewBox="0 0 64 64">{t}{body}</svg>\n'

def build():
    (ROOT/'icons').mkdir(exist_ok=True)
    (ROOT/'favicons').mkdir(exist_ok=True)
    for n in ORDER:
        source=ROOT/'icons'/f'{n}.svg'
        source.write_text(svg(ICONS[n],LABELS[n]))
        # Browser favicon SVG uses precisely the same independent vector source.
        (ROOT/'favicons'/f'{n}.svg').write_text(svg(ICONS[n],LABELS[n]))
        result=subprocess.run(['inkscape',str(source),'--export-type=png','--export-filename=-','--export-width=512'],capture_output=True,check=True)
        raster=Image.open(io.BytesIO(result.stdout)).convert('RGBA')
        for size in (16,24,32,48,64,128,256):
            raster.resize((size,size),Image.Resampling.LANCZOS).save(ROOT/'favicons'/f'{n}-{size}.png')
        raster.save(ROOT/'favicons'/f'{n}.ico',format='ICO',sizes=[(s,s) for s in (16,24,32,48,64,128,256)])
    symbols=''.join(f'<symbol id="sw-{n}" viewBox="0 0 64 64">{ICONS[n]}</symbol>' for n in ORDER)
    (ROOT/'solid-workbench.svg').write_text(f'<svg xmlns="{NS}"><defs>{symbols}</defs></svg>\n')
    make_preview(symbols)
    print(f'Built {len(ORDER)} icons, SVG sprite, PNG/ICO favicons and previews in {ROOT}')

def make_preview(symbols):
    items=[]
    for i,n in enumerate(ORDER):
        col=i%4 if i<12 else (i-12)+1
        row=i//4
        x=30+col*280; y=130+row*280
        items.append(f'<use href="#sw-{n}" x="{x+76}" y="{y}" width="128" height="128"/>')
        items.append(f'<text x="{x+140}" y="{y+158}" text-anchor="middle" font-size="22" font-weight="bold">{LABELS[n]}</text>')
        for j,bg in enumerate(('#F0F3F6',INK)):
            yy=y+176+j*42
            items.append(rect(x+29,yy,222,38,5,bg))
            for size,xx in ((16,61),(24,107),(32,161)):
                items.append(f'<use href="#sw-{n}" x="{x+xx}" y="{yy+(38-size)/2}" width="{size}" height="{size}"/>')
    content=(f'<svg xmlns="{NS}" xmlns:xlink="http://www.w3.org/1999/xlink" width="1180" height="1260" viewBox="0 0 1180 1260">'
             f'<defs>{symbols}</defs><rect width="1180" height="1260" fill="white"/>'
             f'<g fill="{INK}" font-family="DejaVu Sans, sans-serif">'
             '<text x="48" y="54" font-size="32" font-weight="bold">Solid Workbench — Maya-inspired icon family</text>'
             '<text x="48" y="86" font-size="17">Editable vector artwork · exact palette · 16 / 24 / 32 px samples on light and dark</text>'
             +''.join(items)+'</g></svg>')
    # SVG 1.1-compatible references for broad renderer support.
    content=content.replace('<use href=', '<use xlink:href=')
    (ROOT/'preview.svg').write_text(content)
    subprocess.run(['inkscape',str(ROOT/'preview.svg'),'--export-type=png','--export-filename='+str(ROOT/'preview.png')],capture_output=True,check=True)
    cards=[]
    for n in ORDER:
        samples=''.join(f'<img src="favicons/{n}-{s}.png" width="{s}" height="{s}" alt="{s} pixel {LABELS[n]}">' for s in (16,24,32,48))
        cards.append(f'<article><img class="hero" src="icons/{n}.svg" alt=""><h2>{LABELS[n]}</h2><div class="samples">{samples}</div><div class="samples dark">{samples}</div></article>')
    (ROOT/'preview.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Solid Workbench icons</title><style>'
        'body{margin:0;padding:40px;background:#fff;color:#102E42;font:16px system-ui,sans-serif}h1{margin:0 0 10px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:32px;margin-top:36px;max-width:1200px}article{text-align:center}h2{font-size:19px}.hero{width:128px;height:128px}.samples{display:flex;align-items:center;justify-content:center;gap:20px;min-height:64px;background:#f0f3f6;border-radius:6px;margin:6px 0}.dark{background:#102E42}code{font-size:14px}</style>'
        '<h1>Solid Workbench</h1><p>Maya-inspired vector icon family. PNG samples below are shown at actual 16, 24, 32 and 48 CSS pixels.</p>'
        '<p>Blue <code>oklch(65% 0.12 230)</code> / <code>#259CCA</code> · Coral <code>oklch(65% 0.12 30)</code> / <code>#CE7162</code></p><main>'+''.join(cards)+'</main></html>')

if __name__=='__main__':
    build()
