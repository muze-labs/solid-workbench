# Solid Workbench — Maya-inspired icons

Fourteen editable vector icons based on the approved modern Maya-inspired
concept: compact geometric faces, stepped forms, squared spirals with rounded
corners, and a balanced blue/coral palette. Includes the coral Forms checkmark,
Present and Graph.

These are hand-authored vector redrawings of the concept, with small geometry
adjustments for consistent rendering, rather than pixel-identical image traces.
Every icon is real SVG geometry; no embedded bitmaps, fonts, scripts or remote
dependencies. Negative spaces are transparent, not white paint.

## Contents

- `icons/*.svg` — fourteen standalone SVGs with descriptive titles.
- `solid-workbench.svg` — SVG symbol sprite, IDs listed below.
- `favicons/*.svg` — standalone favicon SVGs using the same geometry.
- `favicons/*-{size}.png` — transparent PNGs at 16, 24, 32, 48, 64, 128 and 256 px.
- `favicons/*.ico` — one ICO per app, containing all seven sizes.
- `preview.html` — local browser preview with actual-size PNG samples on light
  and dark backgrounds. Open it from the extracted folder.
- `preview.svg` and `preview.png` — overview with 16/24/32 px vector samples.
- `build.py` — complete editable geometry source and export script.

## Palette

| Role | Design target | Exported sRGB |
| --- | --- | --- |
| Blue | `oklch(65% 0.12 230)` | `#259CCA` |
| Coral | `oklch(65% 0.12 30)` | `#CE7162` |

Both design targets have equal OKLCH lightness and chroma and are inside the
sRGB gamut. The SVGs use the rounded 8-bit sRGB conversions above for predictable
rendering across browsers and image tools. Thus the exported colors are very
close to the OKLCH targets, with normal 8-bit quantization. Anti-aliased edge
pixels have partial alpha; the underlying fill colors are fixed.

Preview text/dark background: `#102E42`; preview light sample background:
`#F0F3F6`. These presentation colors are not part of the icons themselves.

## Geometry and sizing

- Each icon uses `viewBox="0 0 64 64"` and intrinsic size 64 × 64.
- Typical painted bounds are approximately 3–61 on the drawing grid. Optical
  spacing varies by silhouette; all exported bitmap canvases are square.
- Main internal channels are approximately 3–5 drawing units wide, with
  rounded joins. Main corners use roughly 2–9 unit radii.
- SVG luminance masks form the transparent cutouts. IDs are namespaced by app.
- No font is required to display any icon. The SVG overview uses DejaVu Sans
  with a sans-serif fallback; HTML uses the platform system font.
- Raster exports are rendered at 512 px using Inkscape, then resized with
  Pillow's Lanczos filter. ICO frames use the same source geometry.
- No separate simplified micro-icon design is included. At 16 px, small
  spiral openings and facial details soften; inspect the included preview at
  normal browser zoom when choosing display sizes.

## App names and symbol IDs

| App | Filename stem | Symbol ID |
| --- | --- | --- |
| Workbench | `workbench` | `sw-workbench` |
| Contacts | `contacts` | `sw-contacts` |
| Files | `files` | `sw-files` |
| Profile | `profile` | `sw-profile` |
| Zett | `zett` | `sw-zett` |
| Notebook | `notebook` | `sw-notebook` |
| Projects | `projects` | `sw-projects` |
| CRM | `crm` | `sw-crm` |
| Documents | `documents` | `sw-documents` |
| Knowledge | `knowledge` | `sw-knowledge` |
| Forms | `forms` | `sw-forms` |
| Chat | `chat` | `sw-chat` |
| Present | `present` | `sw-present` |
| Graph | `graph` | `sw-graph` |

## Use a standalone SVG

```html
<img src="/assets/icons/contacts.svg" width="32" height="32" alt="Contacts">
```

Use `alt=""` when a neighboring visible label already names the app.

## Use the sprite

```html
<svg width="32" height="32" role="img" aria-label="Contacts">
  <use href="/assets/solid-workbench.svg#sw-contacts"></use>
</svg>
```

Serve an external sprite from the same origin over HTTP(S). Alternatively,
inline its `<defs>` once in the document, inside an SVG with width and height
zero, and reference `href="#sw-contacts"`. Do not inline the sprite multiple
times, because its IDs should remain unique within the page. Use
`aria-hidden="true"` instead of a label for decorative instances.

The sprite contains definitions, so opening it as a normal image appears
blank. Open `preview.svg`, `preview.html`, or an individual SVG instead.

## Favicons

Example for Present; substitute the corresponding filename for each app:

```html
<link rel="icon" href="/assets/favicons/present.ico" sizes="any">
<link rel="icon" href="/assets/favicons/present.svg" type="image/svg+xml">
```

If your integration needs PNG instead:

```html
<link rel="icon" href="/assets/favicons/present-32.png"
      type="image/png" sizes="32x32">
```

Browser favicon caches may keep an old icon; use a changed asset URL when
replacing an existing favicon. The standalone SVG is the scalable favicon;
do not use a fragment of the symbol sprite as a favicon URL.

## Edit and rebuild

Edit shapes or the two palette constants in `build.py`, then run:

```sh
python3 build.py
```

Rebuilding requires Python 3, Pillow, and Inkscape on PATH. The generated files
have no runtime dependencies. The script writes files relative to its own
location and replaces existing exports. Direct edits to generated SVGs are
valid, but a rebuild will overwrite them; make persistent changes in the script.

## Verification

All SVGs were parsed and rendered. Standalone renders were compared against
sprite renders. PNG dimensions, transparency and ICO frame sizes were checked.
The overview was visually reviewed at large and small sizes on light and dark
backgrounds. Browser-specific display can vary with scaling and rasterization.
